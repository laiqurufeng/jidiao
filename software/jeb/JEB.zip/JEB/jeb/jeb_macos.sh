#!/bin/bash

# Start-up script for JEB (MacOS)
source jeb_linux.sh
